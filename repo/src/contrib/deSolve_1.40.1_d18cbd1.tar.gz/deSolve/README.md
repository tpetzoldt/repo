## R Package deSolve

This repository is a fork of the original SVN repository from https://r-forge.r-project.org/projects/desolve/
It is experimental for testing new features.

The code is not (yet) intended for end users, please use the official CRAN package for productive work: https://CRAN.R-project.org/package=deSolve



tpetzoldt 2024-08-13
